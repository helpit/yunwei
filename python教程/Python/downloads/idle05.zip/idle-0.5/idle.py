#! /usr/bin/env python
import PyShell
PyShell.main()
