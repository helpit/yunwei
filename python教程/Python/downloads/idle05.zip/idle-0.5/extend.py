# IDLE extensions to be loaded by default (see extend.txt).
# Edit this file to configure your set of IDLE extensions.

standard = [
    "SearchBinding",
    "AutoIndent",
    "AutoExpand",
    "FormatParagraph",
    "ZoomHeight",
    "ScriptBinding",
    "CallTips",
]
