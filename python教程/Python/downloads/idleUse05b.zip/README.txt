"Using Idle" document

Place all files in the same directory then double click on or start up
the file "idlemain.html" from  a web browser.