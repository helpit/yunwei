"""A tool to generate basic framework for C extension types.

The basic ideas is the same as modulator, but the code generates code
using many of the new features introduced in Python 2.2.  It also
takes a more declarative approach to generating code.
"""
